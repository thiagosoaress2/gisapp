import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';


class CadProdPage extends StatefulWidget {
  @override
  _CadProdPageState createState() => _CadProdPageState();
}

class _CadProdPageState extends State<CadProdPage> {
  File imgFile=null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Cadastrando peça"),
          centerTitle: true,
          backgroundColor: Theme.of(context).primaryColor,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(height: 30.0,),
            Container(
              height: 30.0,
              alignment: Alignment.center,
              child: Text("Upload da foto", style: TextStyle(fontSize: 22.0, color: Colors.grey[500],),),
            ),
            IconButton(
                iconSize: 70.0,
                padding: EdgeInsets.fromLTRB(0.0, 12.0, 0.0, 8.0),
                icon: imgFile==null ? Icon(Icons.photo_camera, color: Colors.grey,) : Icon(Icons.photo_camera, color: Colors.blueAccent),
                onPressed: () async {
                  imgFile = await ImagePicker.pickImage(source: ImageSource.camera); //ele vai pedir pra importar File. Escolhe dart.io

                }
            ),



          ],
        )
    );
  }
}

