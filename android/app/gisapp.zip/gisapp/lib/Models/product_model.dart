import 'package:flutter/material.dart';

class ProductModel extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
