
class MainMode {

  String page = "home";

}